// the current height is802.9090909090909
//the current width is392.72727272727275
import 'package:get/get.dart';

class Dimension {
  static double screenHeight = Get.context!.height;
  static double screenWidth = Get.context!.width;

  static double height10 = screenHeight / 80.29;
  static double height15 = screenHeight / 53.52;
  static double height20 = screenHeight / 40.145;
  static double height30 = screenHeight / 26.76;
  static double height45 = screenHeight / 17.842;
  static double height50 = screenHeight / 16.058;
  static double height60 = screenHeight / 13.38;
  static double height75 = screenHeight / 10.7;

  static double width5 = screenHeight / 160.58;
  static double width10 = screenHeight / 80.29;
  static double width15 = screenHeight / 53.52;
  static double width20 = screenHeight / 40.145;
  static double width30 = screenHeight / 26.76;
  static double width35 = screenHeight / 22.94;
  static double width45 = screenHeight / 17.842;
  static double width50 = screenWidth / 7.8;

  static double radius20 = screenHeight / 40.145;
  static double radius30 = screenHeight / 26.76;
  static double radius15 = screenHeight / 53.52;

  static double font20 = screenHeight / 40.145;
  static double font12 = screenHeight / 66.9;
  static double font13 = screenHeight / 61.76;
  static double font16 = screenHeight / 50.18;
  static double font26 = screenHeight / 30.88;
  static double font30 = screenHeight / 26.76;
  static double font40 = screenHeight / 20.0725;

  static double iconSize24 = screenHeight / 33.45;
  static double iconSize16 = screenHeight / 50.18;
  static double iconSize53 = screenHeight / 15.14;
  static double iconSize50 = screenHeight / 16.058;

  static double height120 = screenHeight / 6.69;
}
